package rafly.example.raflyazzura

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ListView
import android.widget.Toast
import com.example.stevansinaga.R

class Home : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        var listview =  findViewById<ListView>(R.id.listview)
        var list = mutableListOf<Model>()

        list.add(
            Model(
                "Mv Agusta Brutale",
                "Motor Naked 1000cc.",
                R.drawable.motor
            )
        )
        list.add(
            Model(
                "Yamaha R1",
                "Motor Sport Fairing 1000cc.",
                R.drawable.motor2
            )
        )
        list.add(
            Model(
                "Kawasaki ZX10R",
                "Motor sport 1000cc.",
                R.drawable.motor3
            )
        )
        list.add(
            Model(
                "Kawasaki H2R",
                "Motor dengan SuperCharger.",
                R.drawable.motor4
            )
        )
        list.add(
            Model(
                "Suzuki GSXR",
                "Motor Underrated but Overpowered",
                R.drawable.motor5
            )
        )
        list.add(
            Model(
                "KTM duke 1290",
                "Motor Nakes dengan 1290cc",
                R.drawable.motor6
            )
        )
        list.add(
            Model(
                "Ducati",
                "Mototr semi nunduk",
                R.drawable.motor7
            )
        )

        listview.adapter =
            Myadapter(this, R.layout.row, list)

        listview.setOnItemClickListener { parent: AdapterView<*>, view: View, position:Int, id:Long ->
            if (position == 0 ){
                Toast.makeText(this@Home, "Berkisar 700 sampai 900 Juta", Toast.LENGTH_LONG).show()
            }
            if (position == 1 ){
                Toast.makeText(this@Home, "Berkisar 500 sampai 699 Juta", Toast.LENGTH_LONG).show()
            }
            if (position == 2 ){
                Toast.makeText(this@Home, "Berkisar 700 Jutaan", Toast.LENGTH_LONG).show()
            }
            if (position == 3 ){
                Toast.makeText(this@Home, "Berkisar 900 Jutaan.", Toast.LENGTH_LONG).show()
            }
            if (position == 4 ){
                Toast.makeText(this@Home, "Berkisar 1 Milyar", Toast.LENGTH_LONG).show()
            }
            if (position == 5 ){
                Toast.makeText(this@Home, " Berkisar 500 Jutaan", Toast.LENGTH_LONG).show()
            }
            if (position == 6 ){
                Toast.makeText(this@Home, "Berkisar 400 Jutaan", Toast.LENGTH_LONG).show()
            }
        }
    }
}


