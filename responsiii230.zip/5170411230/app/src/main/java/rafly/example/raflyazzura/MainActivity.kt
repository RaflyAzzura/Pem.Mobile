package rafly.example.raflyazzura

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.stevansinaga.R
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn_login.setOnClickListener() {
            val Email = txt_username.text.toString()
            val password = txt_password.text.toString()

            val email_anda = intent.getStringExtra("email_anda")
            val password_anda = intent.getStringExtra("password_anda")

            if (Email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Mohon Masukan Username dan Password Anda", Toast.LENGTH_LONG)
                    .show()
                return@setOnClickListener


            }
            if (Email!= "linggaazzura.la@gmail.com") {
                Toast.makeText(this, "Email Anda Salah", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            } else
                if (password!= "mantap") {
                    Toast.makeText(this, "Password Anda Salah", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener

                }
            intent = Intent(this, Home::class.java)
            intent.putExtra("email_anda", email_anda)
            intent.putExtra("password_anda", password_anda)

            intent.putExtra("email", Email)
            intent.putExtra("password", password)
            startActivity(intent)


        }
        txt_register.setOnClickListener() {
            intent = Intent(this@MainActivity, Register::class.java)
            startActivity(intent)
        }
    }
}


