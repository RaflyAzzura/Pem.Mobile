package rafly.example.raflyazzura

class Model (val title:String, val description:String, val img:Int){}
