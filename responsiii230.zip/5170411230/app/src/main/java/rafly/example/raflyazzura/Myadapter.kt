package rafly.example.raflyazzura

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.ListAdapter
import android.widget.TextView
import com.example.stevansinaga.R

class Myadapter (var mCtx : Context, var resources:Int, var items:List<Model>):
    ArrayAdapter<Model>(mCtx, resources, items), ListAdapter {
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val layoutInflater: LayoutInflater = LayoutInflater.from(mCtx)
            val view: View = layoutInflater.inflate(resources, null)

            val imageView: ImageView = view.findViewById(R.id.image)
            val titleTextView: TextView = view.findViewById(R.id.tv1)
            val descritionTextView: TextView = view.findViewById(R.id.tv2)

            var mItem: Model = items[position]
            imageView.setImageDrawable(mCtx.resources.getDrawable(mItem.img))
            titleTextView.text = mItem.title
            descritionTextView.text = mItem.description


            return view
        }
    }
